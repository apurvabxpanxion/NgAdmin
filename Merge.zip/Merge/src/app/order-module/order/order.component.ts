
import { Component } from "@angular/core";

@Component({
    selector:'order',
    template:`Order`
})
export class OrderComponent {

}