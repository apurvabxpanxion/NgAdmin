import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  items: MenuItem[];
  
  systemItems: MenuItem[];
    constructor() {}

  ngOnInit() {
    this.items = [
      {
        items: [
            {label: 'Price Lists'},
        ]
    },
    {
      label: 'Marketing',
      items: [
          {label: 'Discounts'},
          {label: 'Coupon Sets'},
          {label: 'Product Ranking'},
          {label: 'Search Synonyms'}
      ]
  },
  {
      label: 'Site Builder',
      items: [
          {label: 'Editor'},
          {label: 'Themes'},
          {label: 'Redirects'},
          {label: 'Files'}
      ]
  }, {
  label: 'Marketing',
  items: [
      {label: 'Discounts'},
      {label: 'Coupon Sets'},
      {label: 'Product Ranking'},
      {label: 'Search Synonyms'}
  ]
  },
  {
    label: 'Site Builder',
    items: [
        {label: 'Editor'},
        {label: 'Themes'},
        {label: 'Redirects'},
        {label: 'Files'}
    ]
  },{
  label: 'Marketing',
  items: [
      {label: 'Discounts'},
      {label: 'Coupon Sets'},
      {label: 'Product Ranking'},
      {label: 'Search Synonyms'}
  ]
  },
  {
  label: 'Site Builder',
  items: [
      {label: 'Editor'},
      {label: 'Themes'},
      {label: 'Redirects'},
      {label: 'Files'}
  ]
  }
  ];

  this.systemItems = [
    {
      items: [
          {label: 'Price Lists'},
      ]
  },
  {
    label: 'Site Builder',
    items: [
        {label: 'Editor'},
        {label: 'Themes'},
        {label: 'Redirects'},
        {label: 'Files'}
    ]
},
  {
    label: 'Marketing',
    items: [
        {label: 'Discounts'},
        {label: 'Coupon Sets'},
        {label: 'Product Ranking'},
        {label: 'Search Synonyms'}
    ]
},
{
    label: 'Site Builder',
    items: [
        {label: 'Editor'},
        {label: 'Themes'},
        {label: 'Redirects'},
        {label: 'Files'}
    ]
}
];
  }

    visibleSidebar1;
}
