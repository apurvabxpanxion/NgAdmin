﻿import {
    Component,
    OnInit,
    ChangeDetectionStrategy
} from '@angular/core';

@Component({
    moduleId: module.id,
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'header',
    templateUrl: 'header.component.html',
    styleUrls: ['header.component.css']
})
export class HeaderComponent implements OnInit {
    public tenantName: string;

    constructor(
    ) {}

    ngOnInit() {
        this.tenantName = "RajeshDSandbox";
    }

    
}
