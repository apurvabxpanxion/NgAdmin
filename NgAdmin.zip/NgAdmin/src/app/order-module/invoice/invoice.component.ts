
import { Component } from "@angular/core";

@Component({
    selector:'invoice',
    template:`Invoice`
})
export class InvoiceComponent {

}