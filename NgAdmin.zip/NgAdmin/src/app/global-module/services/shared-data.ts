﻿
export class SharedData {
    sessionId: string;
    userName: string;
    userId: number;
    firstName: string;
    lastName: string;
    entityName: string;
    entityId: number;
    userRoles: { RoleId: number}[];
}

