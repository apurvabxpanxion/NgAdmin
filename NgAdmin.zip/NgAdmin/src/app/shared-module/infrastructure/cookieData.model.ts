﻿export class CookieDataModel {
    isAuthenticated: boolean;
    isImpersonation: boolean;
    integratedPassportToken: string;
    sessionId: string;
}
