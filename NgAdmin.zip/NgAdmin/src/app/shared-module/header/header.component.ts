﻿import {
    Component,
    OnInit,
    ViewChild,
    ChangeDetectionStrategy,
    ElementRef
} from '@angular/core';

import { Router } from '@angular/router';

import { LoggerService } from '@core';

import {
    SharedDataService,
    NotificationService
} from '@global';

import {
    ConfigurationSettings,
    Constants
} from '../infrastructure/index';

import {
    LogoutConfirmationComponent
} from './logout/logout-confirmation.component';

import {
    HttpError,
    ErrorCode,
    ErroNotificationType,
    UtilityService,
    AuthService
} from '@core';

import { environment } from '@env';

@Component({
    moduleId: module.id,
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'header',
    templateUrl: 'header.component.html',
    styleUrls: ['header.component.css']
})
export class HeaderComponent implements OnInit {
    constructor(
    ) {}

    ngOnInit() {
      
    }
}
