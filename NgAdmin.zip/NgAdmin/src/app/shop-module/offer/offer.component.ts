
import { Component } from "@angular/core";

@Component({
    selector:'offer',
    template:`offer`
})
export class OfferComponent {

}