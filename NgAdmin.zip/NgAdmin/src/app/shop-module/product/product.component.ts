
import { Component } from "@angular/core";

@Component({
    selector:'product',
    template:`Product`
})
export class ProductComponent {

}