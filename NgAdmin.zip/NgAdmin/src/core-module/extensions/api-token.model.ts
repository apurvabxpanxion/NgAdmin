﻿
export class ApiTokenModel {
    access_token: string;
    refresh_token: string;
    ".expires": string;
}